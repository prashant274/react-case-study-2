import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import CalculatorComponent from './components/calculatorComponent';
import registerServiceWorker from './registerServiceWorker';

ReactDOM.render(<CalculatorComponent />, document.getElementById('root'));
registerServiceWorker();
