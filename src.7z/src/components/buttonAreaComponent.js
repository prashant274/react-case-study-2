import React, { Component } from 'react';
import ButtonComponent from './buttonComponent';
import '../styles/buttonAreaComponent.css';

class ButtonAreaComponent extends Component {

    constructor() {
        super();
        this.state = {
            symbols: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '+', '-', '*', '/', '=']
        }
    }

    render() {
        return (<div className="buttonAreaComponent">
            {this.state.symbols.map((symbol, index) => <ButtonComponent buttonSymbol={symbol} appendQuery={this.props.appendQuery} calculateResult={this.props.calculateResult} key={index} />)}
        </div>);
    }

}

export default ButtonAreaComponent;