import React, { Component } from 'react';
import '../styles/resultBoxComponent.css';

class ResultBoxComponent extends Component{

render(){
    return(<div className="resultComponent">
        <input type="text"  className="resultBox" value={this.props.query}/>
    </div>);
}


}

export default ResultBoxComponent;