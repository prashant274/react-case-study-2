import React, { Component } from 'react';
import '../styles/buttonComponent.css';
class ButtonComponent extends Component{

processInput(symbol){
    switch(symbol){
        case "=":
        this.props.calculateResult();
        break;
        default:
        this.props.appendQuery(symbol);
    }

}

isOperator(val){
   let ispresent= val.match(/[+*\/-]/g);
    if(ispresent){
        return true;
    }else
    return false;
}

render(){
    return(<button className="buttonComponent" onClick={(e)=>this.processInput(this.props.buttonSymbol)}>{this.props.buttonSymbol}</button>);
}
}

export default ButtonComponent;