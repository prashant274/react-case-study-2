import React, { Component } from 'react';
import ResultBoxComponent from './resultBoxComponent';
import ButtonAreaComponent from './buttonAreaComponent';

import '../styles/calculatorComponent.css';

class CalculatorComponent extends Component{

constructor(){
    super();
    this.state={
        result:0,
        query:"",
    }
    this.appendQuery=this.appendQuery.bind(this);
    this.calculateResult=this.calculateResult.bind(this);
    this.isOperator=this.isOperator.bind(this);
    this.checkForConsecutiveOperator=this.checkForConsecutiveOperator.bind(this);
    this.checkForLastSymbolAsOperator= this.checkForLastSymbolAsOperator.bind(this);
}

appendQuery(symbol){
    let currentQuery=this.state.query;
    let lastSymbol=currentQuery.slice(-1);
    let newQuery;
    newQuery=this.checkForConsecutiveOperator(symbol,lastSymbol,currentQuery);
    this.setState({
        query:newQuery
    });
}

isOperator(symbol){
   if(symbol==="+"||symbol==="-"||symbol==="/"||symbol==="*"){
       return true;
   }else{
       return false;
   }
}

checkForConsecutiveOperator(symbol,lastSymbol,currentQuery){
    let newQuery;
    if(this.isOperator(symbol) && this.isOperator(lastSymbol)){
       newQuery=currentQuery.substr(0,currentQuery.length-1)+symbol; }
     else{
         newQuery=currentQuery+symbol;
    }
    return newQuery;
}

checkForLastSymbolAsOperator(queryToProcess){
    let lastSymbol=queryToProcess.slice(-1);
    if(this.isOperator(lastSymbol)){
       alert("Invalid Query!!");
      return true;
   }
}

calculateResult(){
   let queryToProcess=this.state.query;
   let isInvalidQuery=this.checkForLastSymbolAsOperator(queryToProcess);
   if(isInvalidQuery){
       return;
   }
   let newResult=eval(queryToProcess);
   this.setState({
       result:newResult,
       query:""+newResult
   });
}

render(){
    return(<div className="calculatoBody">
            <ResultBoxComponent query={this.state.query}/>
            <ButtonAreaComponent appendQuery={this.appendQuery} calculateResult={this.calculateResult}/>
    </div>);
}

}

export default CalculatorComponent;